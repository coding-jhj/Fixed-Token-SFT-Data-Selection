# Automatic quality audit (not human rating)

이 보고서는 선택 manifest 전체에 대해 구조·표면 패턴·기존 quality heuristic 재현성을 점검한 자동 audit입니다. 실제 사람의 rating이 아니므로 human audit 또는 factual-quality validation으로 해석하지 않습니다.

## Coverage

- Manifests: 8
- Manifest rows: 8144
- Unique example IDs: 3794
- IDs appearing in more than one manifest: 1827

## Per-manifest quality-score distribution

| Manifest | n | Mean | Median | Min | Max |
|---|---:|---:|---:|---:|---:|
| manifest_diversity_seed13 | 1029 | 0.888012 | 0.893654 | 0.744229 | 0.985110 |
| manifest_diversity_seed2026 | 1027 | 0.886143 | 0.893449 | 0.729505 | 0.985110 |
| manifest_diversity_seed42 | 1021 | 0.888907 | 0.892839 | 0.724721 | 0.985110 |
| manifest_quality_seed13 | 1033 | 0.901980 | 0.900247 | 0.829607 | 0.985110 |
| manifest_quality_seed42 | 1033 | 0.901980 | 0.900247 | 0.829607 | 0.985110 |
| manifest_random_seed13 | 1006 | 0.868754 | 0.876340 | 0.725889 | 0.980405 |
| manifest_random_seed2026 | 995 | 0.866987 | 0.877046 | 0.674099 | 0.979006 |
| manifest_random_seed42 | 1000 | 0.868195 | 0.877225 | 0.673571 | 0.985110 |

## Structural and surface flags

| Flag | Count |
|---|---:|
| assistant_last | 8144 |
| has_assistant | 8144 |
| has_user | 8144 |
| long_repeated_character_run | 1 |
| messages_is_list | 8144 |
| nonempty_assistant | 8144 |
| short_assistant_word_count | 6 |
| valid_message_items | 8144 |

## Heuristic reproducibility

- Stored quality scores that differ from a local re-computation: 0
- Selection overlap is reported as counts only; overlap is expected across policies and seeds and is not a quality failure.

## Blind sample coverage

- Audit-key rows: 200
- Unique IDs: 200
- Found in manifests: 200
- Source counts: {"smol-constraints": 55, "smol-magpie-ultra": 55, "smol-rewrite": 39, "smol-summarize": 51}
- Quality-bin counts: {"high": 72, "low": 58, "mid": 70}

## Limitations

- Surface and heuristic checks cannot determine factual correctness or usefulness for every item.
- A human rater did not participate; this report cannot be called a human audit.
- Repeated content, short responses, or a non-final assistant role are review flags rather than automatic failures.
