# AI-assisted quality audit (not human rating)

이 문서는 실제 사람의 rating이 아닌, 로컬에 캐시된 `Qwen3-1.7B-Base`를 사용한 탐색적 quality-proxy audit입니다. 따라서 논문에서 human agreement 또는 human audit 결과로 보고하면 안 됩니다.

## Scope

- Items: 200
- Both prompt variants parsed: 55 (27.5%)
- Heuristic quality score와 judge overall score의 Spearman correlation: 0.10949960910437329
- Judge overall mean: 4.673 / 5

## Two-prompt consistency

| Criterion | Exact agreement | Mean absolute difference | Unique parsed scores | Max-score rate |
|---|---:|---:|---|---:|
| correctness | 100.0% | 0.000 | [1, 3, 5] | 89.1% |
| instruction_following | 100.0% | 0.000 | [1, 3, 5] | 89.1% |
| clarity | 100.0% | 0.000 | [1, 3, 5] | 89.1% |
| self_containedness | 100.0% | 0.000 | [1, 3, 5] | 89.1% |
| overall_quality | 100.0% | 0.000 | [1, 3, 5] | 89.1% |

## Parsed-judge source summary

| Source | Parsed n | Mean overall (1–5) |
|---|---:|---:|
| smol-constraints | 25 | 4.680 |
| smol-magpie-ultra | 4 | 4.500 |
| smol-rewrite | 4 | 4.000 |
| smol-summarize | 22 | 4.818 |

## Structural checks

- Unique audit example IDs: 200 / 200
- Records found in source manifests: 200 / 200
- Rows with both user and assistant messages: 200 / 200
- Rows with a non-empty assistant message: 200 / 200

## Limitations

- No human rater participated; this cannot be reported as a human audit.
- The judge is the locally cached Qwen3-1.7B-Base model, which is not instruction-tuned and is not independent of the evaluated base model.
- The judge scores are exploratory quality-proxy evidence and do not validate the heuristic against human judgments.
- The two prompt variants are a consistency probe, not independent raters.
- Objective benchmark correctness remains determined by the frozen benchmark scorers, not by this judge.
- In this run only 55/200 items parsed in both passes, and 49/55 parsed overall scores were 5/5; the judge therefore showed weak score discrimination.

Per-item judge outputs are kept in the local workspace only. The curated reproduction ZIP should contain this aggregate report and the script, not the blind text, answer key, or raw per-item evidence.
