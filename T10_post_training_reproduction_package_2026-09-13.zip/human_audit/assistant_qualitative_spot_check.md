# Assistant-led qualitative spot check (not human rating)

이 문서는 실제 사람의 rating이 아니라, assistant가 blind sample의 pre-generated random order에서 처음 20개 항목을 직접 읽고 rubric을 적용한 제한적 spot check입니다. 전체 200개에 대한 human audit, 독립적인 second rater, factual fact-check를 대체하지 않습니다. `audit-014`는 표시된 preview가 길이 제한으로 잘렸으므로 확정 점수를 기록하지 않았습니다.

| Audit ID | Correctness | Instruction following | Clarity | Self-containedness | Overall | 관찰된 이슈 |
|---|---:|---:|---:|---:|---:|---|
| audit-001 | 5 | 2 | 5 | 5 | 3 | 요약 내용은 맞지만 최대 3문장 제약을 넘음 |
| audit-002 | 5 | 3 | 4 | 4 | 4 | 4개 bullet이 한 줄에 있어 Markdown bullet 해석이 모호함 |
| audit-003 | 5 | 5 | 5 | 5 | 5 | 핵심 내용과 전문적 재작성 모두 유지 |
| audit-004 | 4 | 2 | 4 | 4 | 3 | few-formulas 요구를 지키지 않고, 일반화 proof도 끝까지 완결되지 않음 |
| audit-005 | 5 | 5 | 5 | 5 | 5 | 핵심 협업 제안을 정확히 압축 |
| audit-006 | 5 | 5 | 5 | 5 | 5 | 문장 수·placeholder·P.S. 제약을 충족 |
| audit-007 | 3 | 4 | 5 | 5 | 4 | 원문의 중국어 문장에 담긴 내용을 보존하지 않음 |
| audit-008 | 4 | 5 | 5 | 4 | 4 | 핵심은 요약했으나 webinar 관련 세부사항은 생략 |
| audit-009 | 5 | 5 | 5 | 5 | 5 | 친근한 어조와 요청의 핵심을 유지 |
| audit-010 | 4 | 5 | 5 | 5 | 4 | 전문적·완화된 표현이지만 coordinator escalation의 명시성이 약해짐 |
| audit-011 | 5 | 5 | 5 | 5 | 5 | 일정과 추천 도서를 한 문장에 정확히 포함 |
| audit-012 | 4 | 2 | 4 | 4 | 3 | 최대 3문장 제약을 넘고 원문에 없는 지원 전화번호를 추가 |
| audit-013 | 5 | 5 | 5 | 5 | 5 | 일정·목적·협업 의사를 간결하게 보존 |
| audit-014 | N/A | N/A | N/A | N/A | N/A | preview가 잘려 전체 응답을 판정하지 않음 |
| audit-015 | 5 | 5 | 5 | 5 | 5 | 실행 계획, 일정, 역할 제안이 요청과 일치 |
| audit-016 | 4 | 5 | 5 | 5 | 4 | 기한은 유지했지만 원문의 escalation 조건이 완화됨 |
| audit-017 | 5 | 5 | 5 | 5 | 5 | 파트너·survey·자료 전달 핵심을 모두 보존 |
| audit-018 | 5 | 5 | 5 | 5 | 5 | 예시가 요구한 문장·placeholder·P.S.를 충족 |
| audit-019 | 5 | 5 | 5 | 5 | 5 | 핵심 action을 정확히 한 문장으로 압축 |
| audit-020 | 5 | 5 | 5 | 5 | 5 | 전문적 재작성으로 핵심과 의도를 유지 |

## Interpretation

관찰된 실패 유형은 주로 factual error보다 명시적 형식 제약 누락, 원문의 일부 정보 손실, 불필요한 추가 정보입니다. 이는 현재 `quality_score`가 영어 신호·response length·반복·artifact를 측정하는 선택 heuristic이지 instruction-following 또는 factuality label이 아니라는 점과 일치합니다. 이 표의 점수는 exploratory qualitative notes로만 보존하며, 평균 성능·human agreement·선택기의 causal effect를 검정하는 통계로 사용하지 않습니다.
