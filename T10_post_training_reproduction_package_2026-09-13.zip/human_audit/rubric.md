# Blind quality audit rubric

각 항목을 1~5점으로 평가합니다. 평가자는 `blind_items.jsonl`만 보고 평가하며 `answer_key.jsonl`과 `sampling_manifest.csv`는 보지 않습니다.

- Correctness: 내용이 사실에 맞고 질문에 적절히 답하는가.
- Instruction following: 명시된 형식·제약·요구를 지키는가.
- Clarity: 읽기 쉽고 모호하지 않은가.
- Self-containedness: 외부 정보 없이 답변 자체가 충분한가.
- Overall quality: 위 항목을 종합한 전체 품질.

1점은 심각한 결함, 3점은 부분적으로 유용하지만 개선 필요, 5점은 명확하고 완전한 답변입니다. 판단이 불가능하면 별도 `uncertain` 플래그를 기록합니다. 자동 점수는 사람이 평가한 뒤에만 비교합니다.
