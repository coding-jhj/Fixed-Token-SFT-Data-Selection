# Raw output redistribution boundary

Raw evaluation JSONL files remain in the workspace under `work/evaluation_final_balanced/` and are represented here only by size and SHA-256 metadata. They are not copied into this ZIP because the local audit did not establish a clear redistribution license for the BBH conversion source.
