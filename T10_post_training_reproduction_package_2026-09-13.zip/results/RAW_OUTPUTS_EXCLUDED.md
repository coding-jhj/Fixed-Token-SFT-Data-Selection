# Raw output redistribution boundary

Raw evaluation JSONL files remain in the workspace under the primary and follow-up `work/evaluation_*` directories and are represented here only by size and SHA-256 metadata. They are not copied into this ZIP because the local audit did not establish a clear redistribution license for the BBH conversion source. Human audit blind text is also kept in the workspace; the ZIP contains only its rubric and sampling manifest.
